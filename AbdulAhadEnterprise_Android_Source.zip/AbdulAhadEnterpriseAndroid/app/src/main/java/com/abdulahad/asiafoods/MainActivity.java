package com.abdulahad.asiafoods;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
 DB db; LinearLayout root,body; ArrayList<Product> products=new ArrayList<>(); ArrayList<Customer> customers=new ArrayList<>(); ArrayList<Cart> cart=new ArrayList<>();
 TextView totalView; Spinner prodSpinner,customerSpinner,unitSpinner; EditText qtyInput;
 public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);load();home();}
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
 Button btn(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
 EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine();return e;}
 void base(String title){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(12),dp(12),dp(12),dp(12));root.setBackgroundColor(0xfff2f5f4);
 TextView h=text("Abdul Ahad Enterprise — Asia Food's",20);h.setTypeface(null,Typeface.BOLD);h.setTextColor(0xff155c3b);root.addView(h);root.addView(text(title,18));ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
 LinearLayout nav=new LinearLayout(this);for(String s:new String[]{"বিক্রয়","পণ্য","কাস্টমার","বাকি","রিপোর্ট"})nav.addView(btn(s,()->{switch(s){case "বিক্রয়":home();break;case "পণ্য":productPage();break;case "কাস্টমার":customerPage();break;case "বাকি":duePage();break;default:reportPage();}}),new LinearLayout.LayoutParams(0,-2,1));root.addView(nav);setContentView(root);}
 void load(){products=db.products();customers=db.customers();}
 void home(){load();base("নতুন বিক্রয়");customerSpinner=new Spinner(this);ArrayList<String> cs=new ArrayList<>();cs.add("Cash Customer");for(Customer c:customers)cs.add(c.name);customerSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cs));body.addView(text("কাস্টমার",14));body.addView(customerSpinner);
 prodSpinner=new Spinner(this);ArrayList<String> ps=new ArrayList<>();for(Product p:products)ps.add(p.name+" | ৳"+p.price+" | স্টক "+p.stock);prodSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ps));body.addView(text("পণ্য",14));body.addView(prodSpinner);
 qtyInput=input("পরিমাণ");qtyInput.setInputType(2);qtyInput.setText("1");body.addView(qtyInput);unitSpinner=new Spinner(this);unitSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"পিস","কার্টন"}));body.addView(unitSpinner);
 body.addView(btn("মেমোতে যোগ",()->addCart()));totalView=text("মোট: ৳"+sum(),22);body.addView(totalView);renderCart();
 body.addView(btn("নগদ বিক্রয় সংরক্ষণ",()->checkout(false)));body.addView(btn("বাকি বিক্রয় সংরক্ষণ",()->checkout(true)));body.addView(btn("মেমো প্রিন্ট",()->printMemo()));}
 void addCart(){if(products.isEmpty()){toast("আগে পণ্য যোগ করুন");return;}int i=Math.max(0,prodSpinner.getSelectedItemPosition());Product p=products.get(i);int q=1;try{q=Integer.parseInt(qtyInput.getText().toString());}catch(Exception ignored){}if(q<1)q=1;cart.add(new Cart(p.id,p.name,q,p.price,unitSpinner.getSelectedItem().toString()));home();}
 int sum(){int s=0;for(Cart c:cart)s+=c.qty*c.price;return s;}
 void renderCart(){for(Cart c:cart)body.addView(text(c.name+"  "+c.qty+" "+c.unit+" × ৳"+c.price+" = ৳"+(c.qty*c.price),14));if(!cart.isEmpty())body.addView(btn("মেমো খালি করুন",()->{cart.clear();home();}));}
 void checkout(boolean due){if(cart.isEmpty()){toast("মেমোতে পণ্য যোগ করুন");return;}String cust=customerSpinner.getSelectedItem().toString();long sid=db.sale(cust,sum(),due?1:0,cart);cart.clear();load();home();toast("বিক্রয় সংরক্ষিত #"+sid);}
 void printMemo(){if(cart.isEmpty()){toast("প্রিন্ট করার আগে পণ্য যোগ করুন");return;}StringBuilder s=new StringBuilder("Abdul Ahad Enterprise\nAsia Food's\n----------------------\n");for(Cart c:cart)s.append(c.name+" "+c.qty+" "+c.unit+" x "+c.price+" = "+c.qty*c.price+"\n");s.append("----------------------\nTOTAL: ৳").append(sum()).append("\nThank you");new AlertDialog.Builder(this).setTitle("মেমো (Print preview)").setMessage(s.toString()).setPositiveButton("ঠিক আছে",null).show();}
 void productPage(){load();base("পণ্য ও স্টক");EditText n=input("পণ্যের নাম"),p=input("বিক্রয় মূল্য (৳)"),st=input("স্টক"),un=input("একক: পিস/কার্টন");p.setInputType(2);st.setInputType(2);body.addView(n);body.addView(p);body.addView(st);body.addView(un);body.addView(btn("পণ্য যোগ করুন",()->{if(n.getText().length()==0)return;db.addProduct(n.getText().toString(),num(p),num(st),un.getText().length()==0?"পিস":un.getText().toString());productPage();}));for(Product x:products){body.addView(text(x.name+" | ৳"+x.price+" | স্টক "+x.stock,15));body.addView(btn("দাম/স্টক এডিট: "+x.name,()->editProduct(x)));}}
 int num(EditText e){try{return Integer.parseInt(e.getText().toString());}catch(Exception x){return 0;}}
 void editProduct(Product x){EditText p=input("নতুন মূল্য");p.setText(""+x.price);EditText st=input("নতুন স্টক");st.setText(""+x.stock);new AlertDialog.Builder(this).setTitle(x.name).setView(wrap(p,st)).setPositiveButton("Save",(d,w)->{db.updateProduct(x.id,num(p),num(st));productPage();}).setNegativeButton("Cancel",null).show();}
 View wrap(View a,View b){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.addView(a);l.addView(b);return l;}
 void customerPage(){load();base("কাস্টমার");EditText n=input("কাস্টমারের নাম"),ph=input("মোবাইল");body.addView(n);body.addView(ph);body.addView(btn("কাস্টমার যোগ",()->{if(n.getText().length()>0){db.addCustomer(n.getText().toString(),ph.getText().toString());customerPage();}}));for(Customer c:customers)body.addView(text(c.name+" | "+c.phone+" | বাকি ৳"+db.due(c.name),15));}
 void duePage(){base("বাকি হিসাব");for(Customer c:customers){int d=db.due(c.name);if(d>0){body.addView(text(c.name+" — বাকি ৳"+d,16));EditText amt=input("আদায়ের পরিমাণ");amt.setInputType(2);body.addView(amt);body.addView(btn("আদায় জমা",()->{db.pay(c.name,num(amt));duePage();}));}}}
 void reportPage(){base("সাপ্তাহিক / মাসিক রিপোর্ট");body.addView(text("মোট বিক্রয়: ৳"+db.totalSales(),20));body.addView(text("আজকের বিক্রয়: ৳"+db.todaySales(),18));body.addView(text("এই মাসের বিক্রয়: ৳"+db.monthSales(),18));}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
 class Product{int id,price,stock;String name,unit;Product(int i,String n,int p,int s,String u){id=i;name=n;price=p;stock=s;unit=u;}}
 class Customer{String name,phone;Customer(String n,String p){name=n;phone=p;}}
 class Cart{int id,qty,price;String name,unit;Cart(int i,String n,int q,int p,String u){id=i;name=n;qty=q;price=p;unit=u;}}
 class DB extends SQLiteOpenHelper{
 DB(Context c){super(c,"asiafoods.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY,name TEXT,price INTEGER,stock INTEGER,unit TEXT)");d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY,name TEXT,phone TEXT)");d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY,date TEXT,customer TEXT,total INTEGER,due INTEGER)");d.execSQL("CREATE TABLE items(sale INTEGER,pid INTEGER,name TEXT,qty INTEGER,price INTEGER,unit TEXT)");d.execSQL("CREATE TABLE payments(customer TEXT,amount INTEGER,date TEXT)");}public void onUpgrade(SQLiteDatabase d,int a,int b){}
 ArrayList<Product> products(){ArrayList<Product> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT * FROM products",null);while(c.moveToNext())a.add(new Product(c.getInt(0),c.getString(1),c.getInt(2),c.getInt(3),c.getString(4)));c.close();return a;}
 ArrayList<Customer> customers(){ArrayList<Customer>a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT name,phone FROM customers",null);while(c.moveToNext())a.add(new Customer(c.getString(0),c.getString(1)));c.close();return a;}
 void addProduct(String n,int p,int s,String u){ContentValues v=new ContentValues();v.put("name",n);v.put("price",p);v.put("stock",s);v.put("unit",u);getWritableDatabase().insert("products",null,v);}
 void updateProduct(int id,int p,int s){ContentValues v=new ContentValues();v.put("price",p);v.put("stock",s);getWritableDatabase().update("products",v,"id=?",new String[]{""+id});}
 void addCustomer(String n,String ph){ContentValues v=new ContentValues();v.put("name",n);v.put("phone",ph);getWritableDatabase().insert("customers",null,v);}
 long sale(String c,int total,int due,ArrayList<Cart> items){SQLiteDatabase d=getWritableDatabase();ContentValues v=new ContentValues();v.put("date",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));v.put("customer",c);v.put("total",total);v.put("due",due);long id=d.insert("sales",null,v);for(Cart x:items){ContentValues it=new ContentValues();it.put("sale",id);it.put("pid",x.id);it.put("name",x.name);it.put("qty",x.qty);it.put("price",x.price);it.put("unit",x.unit);d.insert("items",null,it);d.execSQL("UPDATE products SET stock=MAX(0,stock-?) WHERE id=?",new Object[]{x.qty,x.id});}return id;}
 int due(String c){Cursor x=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales WHERE customer=? AND due=1",new String[]{c});x.moveToFirst();int a=x.getInt(0);x.close();Cursor p=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE customer=?",new String[]{c});p.moveToFirst();a-=p.getInt(0);p.close();return a;}
 void pay(String c,int a){ContentValues v=new ContentValues();v.put("customer",c);v.put("amount",a);v.put("date",new SimpleDateFormat("yyyy-MM-dd").format(new Date()));getWritableDatabase().insert("payments",null,v);}
 int totalSales(){return scalar("SELECT COALESCE(SUM(total),0) FROM sales");}int todaySales(){return scalar("SELECT COALESCE(SUM(total),0) FROM sales WHERE date LIKE '"+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+"%'");}int monthSales(){return scalar("SELECT COALESCE(SUM(total),0) FROM sales WHERE date LIKE '"+new SimpleDateFormat("yyyy-MM").format(new Date())+"%'");}
 int scalar(String q){Cursor c=getReadableDatabase().rawQuery(q,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
 }
}